import React, {
  useEffect,
  useState,
} from "react";
import { useNavigate } from "react-router-dom";

const API = "https://ghostinbox09.onrender.com/api";

const Discover = () => {
  const navigate = useNavigate();

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  // ==================================================
  // SEARCH DEBOUNCE
  // ==================================================

  useEffect(() => {
    const timer = setTimeout(() => {
      loadUsers(search);
    }, 350);

    return () => {
      clearTimeout(timer);
    };
  }, [search]);

  // ==================================================
  // LOAD USERS
  // ==================================================

  const loadUsers = async (
    searchValue = ""
  ) => {
    try {
      setLoading(true);
      setError("");

      let url = `${API}/discover`;

      if (searchValue.trim()) {
        url += `?search=${encodeURIComponent(
          searchValue.trim()
        )}`;
      }

      const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Failed to load users"
        );
      }

      setUsers(data.users || []);
    } catch (error) {
      console.error(
        "Discover error:",
        error
      );

      setUsers([]);

      setError(
        error.message ||
          "Failed to load discover users"
      );
    } finally {
      setLoading(false);
    }
  };

  // ==================================================
  // SEARCH
  // ==================================================

  const handleSearch = (event) => {
    setSearch(event.target.value);
  };

  // ==================================================
  // OPEN PROFILE
  // ==================================================

  const handleProfile = (user) => {
    navigate(`/profile/${user._id}`, {
      state: {
        user,
      },
    });
  };

  // ==================================================
  // OPEN CHAT
  // ==================================================

  const handleChat = (
    event,
    user
  ) => {
    event.stopPropagation();

    navigate("/chat", {
      state: {
        user,
      },
    });
  };

  return (
    <main className="discover-page">

      <div className="discover-container">

        {/* HEADER */}

        <header className="discover-header">

          <div>
            <h1>Discover</h1>

            <p>
              People who match your interests
            </p>
          </div>

          <button
            type="button"
            className="discover-filter"
            aria-label="Filters"
          >
            <span></span>
            <span></span>
            <span></span>
          </button>

        </header>

        {/* SEARCH */}

        <div className="discover-search">

          <span className="discover-search-icon">
            🔍
          </span>

          <input
            type="text"
            value={search}
            onChange={handleSearch}
            placeholder="Search username..."
            aria-label="Search username"
          />

          {search && (
            <button
              type="button"
              className="discover-search-clear"
              onClick={() =>
                setSearch("")
              }
              aria-label="Clear search"
            >
              ×
            </button>
          )}

        </div>

        {/* USERS */}

        <section className="discover-list">

          {/* LOADING */}

          {loading && (
            <div className="discover-status">

              <div className="discover-loader"></div>

              <p>
                {search.trim()
                  ? "Searching users..."
                  : "Finding your matches..."}
              </p>

            </div>
          )}

          {/* ERROR */}

          {!loading && error && (
            <div className="discover-status">

              <div className="discover-status-icon">
                !
              </div>

              <h2>
                Unable to load matches
              </h2>

              <p>{error}</p>

            </div>
          )}

          {/* EMPTY */}

          {!loading &&
            !error &&
            users.length === 0 && (
              <div className="discover-status">

                <div className="discover-status-icon">
                  ✦
                </div>

                <h2>
                  {search.trim()
                    ? "No users found"
                    : "No matches yet"}
                </h2>

                <p>
                  {search.trim()
                    ? `No username starts with "${search}".`
                    : "We'll show people who match your preferences here."}
                </p>

              </div>
            )}

          {/* USERS */}

          {!loading &&
            !error &&
            users.map((user) => (
              <article
                className="discover-card"
                key={user._id}
                onClick={() =>
                  handleProfile(user)
                }
              >

                <div className="discover-photo">

                  {user.photo ? (
                    <img
                      src={user.photo}
                      alt={
                        user.username ||
                        "User"
                      }
                    />
                  ) : (
                    <div className="discover-photo-fallback">
                      {user.username
                        ?.charAt(0)
                        ?.toUpperCase() ||
                        "?"}
                    </div>
                  )}

                </div>

                <div className="discover-user-info">

                  <h3>
                    {user.username}
                  </h3>

                  <p>
                    {user.gender}

                    {user.age
                      ? ` • ${user.age}`
                      : ""}
                  </p>

                </div>

                {user.category && (
                  <span
                    className={`discover-badge ${
                      user.category.toLowerCase() ===
                      "casual"
                        ? "casual"
                        : "loyal"
                    }`}
                  >
                    {user.category}
                  </span>
                )}

                <button
                  type="button"
                  className="discover-chat-button"
                  onClick={(event) =>
                    handleChat(
                      event,
                      user
                    )
                  }
                >
                  Chat
                </button>

              </article>
            ))}

        </section>

        {/* BOTTOM NAV */}

        <nav className="discover-bottom-nav">

          <button
            type="button"
            className="discover-nav active"
            onClick={() =>
              navigate("/discover")
            }
          >
            <span className="discover-nav-icon">
              ◉
            </span>

            <span>
              Discover
            </span>
          </button>

          <button
            type="button"
            className="discover-nav"
            onClick={() =>
              navigate("/requests")
            }
          >
            <span className="discover-nav-icon">
              ♧
            </span>

            <span>
              Requests
            </span>
          </button>

          <button
            type="button"
            className="discover-nav"
            onClick={() =>
              navigate("/chat")
            }
          >
            <span className="discover-nav-icon">
              ○
            </span>

            <span>
              Chat
            </span>
          </button>

          <button
            type="button"
            className="discover-nav"
            onClick={() =>
              navigate("/profile")
            }
          >
            <span className="discover-nav-icon">
              ♙
            </span>

            <span>
              Profile
            </span>
          </button>

        </nav>

      </div>

    </main>
  );
};

export default Discover;